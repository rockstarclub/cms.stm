<?php
	/*
	* Első magyar fordítás 1.4.2 verzióig: Lukács Péter <programozo@lukacspeter.hu>
	*/
	
  // Reporting
  return array(
  
  	'custom' => 'Egyedi',
    'custom reports' => 'Egyedi jelentések',
  	'no custom reports' => 'Nincsenek egyedi jelentések',
  	'add custom report' => 'Egyedi jelentés létrehozása',
  	'edit custom report' => 'Egyedi jelentés szerkesztése',
  	'new custom report' => 'Új egyedi jelentés',
  	'add report' => 'Jelentés létrehozása',
  	'object type' => 'Objektum típus',
  	'add condition' => 'Feltétel hozzáadása',
  	'custom report created' => 'Egyedi jelentés létrehozva',
  	'custom report updated' => 'Egyedi jelentés módosítva',
  	'conditions' => 'Feltételek',
  	'columns and order' => 'Oszlopok és elrendezés',
  	'true' => 'Igaz',
  	'false' => 'Hamis',
  	'field' => 'Mező',
  	'condition' => 'Feltétel',
  	'ends with' => 'erre végződik:',
  	'select unselect all' => 'Az összes kiválasztása/kiválasztás megszűntetése',
  	'ascending' => 'Emelkedő',
  	'descending' => 'Csökkenő',
  );
  
?>