<?php
return array(
	'_language_name' => 'Magyar',
	'_ext_language_file' => 'ext-lang-en-min.js',
);
?>