<?php
	
	/*
	* Első magyar fordítás 1.4.2 verzióig: Lukács Péter <programozo@lukacspeter.hu>
	*/
	
	return array(
		'upgrade' => 'Szoftverfrissítés',
		'upgrade from' => 'Frissítés miről',
		'upgrade to' => 'Frissítés mire',
		'already upgraded' => 'Ön már rendelkezik a legfrissebb verzióval.',
		'back to fengoffice' => 'Vissza az Feng Office-ba',
		'all rights reserved' => 'Minden jog fenntartva',
		'upgrade process log' => 'Frissítési folyamat napló',
		'upgrade fengoffice' => 'Az Feng Office frissítése',
		'upgrade your fengoffice installation' => 'Az Ön telepített Feng Office verziójának frissítése'
	);
?>