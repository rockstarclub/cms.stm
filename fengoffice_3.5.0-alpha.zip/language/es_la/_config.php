<?php
return array(
	'_language_name' => 'Español (Latinoamérica)',
	'_ext_language_file' => 'ext-lang-es-min.js',
);
?>