<?php
return array(
	'_language_name' => 'English (U.S.)',
	'_ext_language_file' => 'ext-lang-en-min.js',
);
?>