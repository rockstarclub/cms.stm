<?php
return array(
	'_language_name' => 'Hrvatski Jezik (Croatian)',
	'_ext_language_file' => 'ext-lang-hr-min.js',
);
?>