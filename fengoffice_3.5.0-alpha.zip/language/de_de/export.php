<?php return array(
	'error exporting file' => 'Fehler beim Export von {0}.',
	'export to pdf' => 'Export ins PDF-Format',
	'file type not supported' => 'Dateityp wird nicht unterstützt.',
); ?>
