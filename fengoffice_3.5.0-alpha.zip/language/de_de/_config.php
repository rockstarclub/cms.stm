<?php return array(
	'_language_name' => 'Deutsch',
	'_ext_language_file' => 'ext-lang-de-min.js',
); ?>
