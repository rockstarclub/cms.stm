<?php
return array(
	'_language_name' => 'Lietuvių',
	'_ext_language_file' => 'ext-lang-lt-min.js',
);
?>