<?php
return array(
	'_language_name' => 'Ελληνικά',
	'_ext_language_file' => 'ext-lang-el_GR-min.js',
);
?>