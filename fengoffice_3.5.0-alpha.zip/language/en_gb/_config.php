<?php
return array(
	'_language_name' => 'English (U.K.)',
	'_ext_language_file' => 'ext-lang-en_GB-min.js',
);
?>