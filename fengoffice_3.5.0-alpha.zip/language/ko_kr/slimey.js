locale = 'ko_kr';
addLangs({
});
