<?php return array(
	'_language_name' => '한국어',
	'_ext_language_file' => 'ext-lang-ko-min.js',
); ?>
