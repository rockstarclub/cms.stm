<?php return array(
	'upgrade' => '업그레이드',
	'upgrade from' => '다음으로부터 업그레이드',
	'upgrade to' => '다음으로 업그레이드',
	'already upgraded' => '당신은 최근 가능한 버전으로 업그레이드 했습니다.',
	'back to fengoffice' => '오픈구로 돌아가기',
	'all rights reserved' => '모든 권리 가짐',
	'upgrade process log' => '업그레이드 과정 로드',
	'upgrade fengoffice' => '오픈구 업그레이드',
	'upgrade your fengoffice installation' => '당신에 오픈구 설치 업그레이드',
); ?>
