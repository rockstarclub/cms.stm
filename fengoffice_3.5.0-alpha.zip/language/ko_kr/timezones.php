<?php return array(
	'timezone gmt +9' => '(GMT+9:00) 서울, 도쿄, 오사카, 사뽀로, 야츠쿠',
); ?>
