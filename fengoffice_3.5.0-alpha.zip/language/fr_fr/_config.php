<?php
return array(
	'_language_name' => 'Français',
	'_ext_language_file' => 'ext-lang-fr_FR.js',
);
?>