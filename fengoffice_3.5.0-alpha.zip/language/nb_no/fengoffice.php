<?php return array(
	'free trial upgrade' => 'Dette er en 30-dagers prøveversjon. Ønsker du å beholde all informasjon på systemet og fortsette å bruke våre tjenester: <a class="dashboard-link" href="http://www.fengoffice.com/web/pricing.php">Oppgrader til abonnement</a>',
	'chelp add event linked objects' => 'Du kan lenke annen relevant informasjon til dette objektet',
	'chelp add event invitation' => 'Velg brukere for å invitere til arrangementet.',
	'chelp personal account' => '<b>Velkommen til kontopanelet</b><br/>
							I dette menyvalget kan du redigere din personlige informasjon.<br/>
							Listen til høyre viser de ulike handlingene som er tilgjengelige. De viktigste alternativene er:<br/>
							<b>Oppdater profilen:</b> Lar deg oppdatere din informasjon.<br/>
							<b>Skift passord:</b> Lar deg endre passordet ditt.<br/>',
	'chelp add new task workspace' => 'Dette alternativet lar deg velge hvilket arbeidsområde objektet skal lagres på',
	'chelp add new task tag' => 'Dette alternativet lar deg legge til et stikkord for objektet. Dette er nyttig i og med at stikkord er hurtige å slå opp senere, og gjør det enklere å søke',
	'chelp add new task linked object' => 'Du kan legge til lenker til relevant informasjon for dette objektet.',
	'chelp add milestone linked object' => 'Du kan lenke relevant informasjon til dette objektet',
	'chelp add note linked objects' => 'Du kan lenke relevant informasjon til dette objektet.',
	'chelp add new task custom properties' => 'Du har mulighet til å velge dine egne nye egenskaper etter dine egne behov.',
	'chelp add milestone custom properties' => 'Du har mulighet til å velge dine egne nye egenskaper etter dine egne behov.',
	'chelp company card' => 'Dette er foretakskortet',
	'chelp add note custom properties' => 'Du har mulighet til å velge dine egne nye egenskaper, etter dine egne behov.',
	'chelp upload file description' => 'Dette alternativet lar deg beskrive objektets innhold.',
	'chelp upload file custom properties' => 'Du har mulighet til å velge dine egne nye egenskaper, etter dine egne behov.',
	'chelp add webpage custom properties' => 'Du har mulighet til å velge dine egne nye egenskaper etter dine egne behov.',
	'chelp add event custom properties' => 'Du har mulighet til å velge dine egne nye egenskaper, etter dine egne behov.',
); ?>
