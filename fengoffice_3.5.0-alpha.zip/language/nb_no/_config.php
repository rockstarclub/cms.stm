<?php return array(
	'_language_name' => 'Norsk - Bokmål',
	'_ext_language_file' => 'ext-lang-no_NB-min.js',
); ?>
