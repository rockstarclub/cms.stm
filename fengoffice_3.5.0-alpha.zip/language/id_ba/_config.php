<?php
return array(
	'_language_name' => 'Bahasa',
	'_ext_language_file' => 'ext-lang-id-min.js',
);
?>