<?php
return array(
	'_language_name' => 'Čeština',
	'_ext_language_file' => 'ext-lang-cs-min.js',
);
?>