<?php return array(
	'error exporting file' => 'Erreur d\'export vers {0}.',
	'export to pdf' => 'Exporter en PDF',
	'file type not supported' => 'Ce type de fichier n\'est pas supporté.',
); ?>
