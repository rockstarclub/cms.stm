<?php
return array(
	'_language_name' => 'Español (España)',
	'_ext_language_file' => 'ext-lang-es-min.js',
);
?>