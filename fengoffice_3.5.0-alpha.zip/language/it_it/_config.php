<?php return array(
	'_language_name' => 'Italiano',
	'_ext_language_file' => 'ext-lang-it-min.js',
); ?>
