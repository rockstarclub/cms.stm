<?php
return array(
	'_language_name' => '日本語',
	'_ext_language_file' => 'ext-lang-ja-min.js',
);
?>
