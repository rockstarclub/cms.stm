<?php return array(
	'_language_name' => 'Nederlands',
	'_ext_language_file' => 'ext-lang-nl-min.js',
); ?>
